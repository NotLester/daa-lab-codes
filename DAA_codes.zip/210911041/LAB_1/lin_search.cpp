#include <iostream>
using namespace std;

int cnt = 0;

int linearSearch(int a[], int n, int target) {

    for (int i=0; i<n; i++) {
        cnt++;
        cnt++;
        if (a[i] == target) {
            cnt++;
            return i;
        }
    }
    cnt++;
    cnt++;
    return -1;
}


int main() {

    int n, target;
    cin>> n;
    int a[n];
    for (int i=0; i<n; i++) {
        cin>> a[i];
    }
    cin>> target;
    cout<< "Found at index: "<< linearSearch(a,n,target) <<endl;
    cout<< "Step count: "<< cnt <<endl;
    return 0;
}
