#include <bits/stdc++.h>
using namespace std;

int dp[1000][1000];

bool getSum(int a[], int n, int sum) {
    if (sum == 0) return 1;
    if (n == 0) return 0;

    if (dp[n-1][sum] != -1)
        return dp[n-1][sum];

    if (a[n-1] > sum)
        return dp[n-1][sum] = getSum(a,n-1,sum);

    return dp[n-1][sum] = getSum(a,n-1,sum) || getSum(a,n-1,sum - a[n-1]);
}

int main() {

    memset(dp,-1,sizeof(dp));
    int n = 6;
    int a[n] = {3,34,4,12,5,2};
    int sum = 9;
    cout<< getSum(a,n,sum) <<endl;

    return 0;
}
