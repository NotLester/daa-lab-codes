#include <bits/stdc++.h>
using namespace std;



int KnapsackDP(int W, int wt[], int profit[], int n) {
    int dp[n+1][W+1];
    memset(dp,0,sizeof(dp));

    for (int i=1; i<=n; i++) {
        for (int j = 0; j<=W; j++)
            if (wt[i] > j)
                dp[i][j] = dp[i-1][j];
            else dp[i][j] = max(profit[i]+dp[i-1][j-wt[i]], dp[i-1][j]);
    }

    return dp[n][W];
}

int main() {

    int n;
    cout<< "Enter number of items: ";
    cin>> n;
    int p[n+1],w[n+1],x[n] = {0};
    for (int i=1; i<=n; i++) {
        cout<< "Enter profit and weight of item " << i << ": ";
        cin>> p[i] >> w[i];
    }
    cout<< "Enter capacity: ";
    int W;
    cin>> W;


    cout<< "Maximum profit: " << KnapsackDP(W,w,p,n) <<endl;

    return 0;
}
