#include <iostream>
#include <vector>

using namespace std;

void DFS(vector<vector<int>>& graph, int vertex, vector<bool>& visited) {
    visited[vertex] = true;
    for (int i = 0; i < graph.size(); i++) {
        if (graph[vertex][i] && !visited[i]) {
            DFS(graph, i, visited);
        }
    }
}

bool isConnected(vector<vector<int>>& graph) {
    int n = graph.size();
    vector<bool> visited(n, false);
    DFS(graph, 0, visited);
    for (int i = 0; i < n; i++) {
        if (!visited[i]) {
            return false;
        }
    }
    return true;
}

int main() {

//#ifndef ONLINE_JUDGE
	//freopen("input.txt","r",stdin);
	//freopen("output.txt","w",stdout);
//#endif

	int n, m;
	cout<< "Enter nodes and edges: ";
    cin >> n >> m;
    vector<vector<int>> graph(n, vector<int>(n, 0));
    for (int i = 0; i < m; i++) {
        int u, v;
        cin >> u >> v;
        graph[u][v] = 1;
    }
    if (isConnected(graph)) {
        cout << "Graph is connected" << endl;
    } else {
        cout << "Graph is not connected" << endl;
    }

	return 0;
}

/*
4 3
0 1
1 2
2 0
*/






































// Pseudocode
// Define a function 'DFS' that takes a node 'v' as input and performs a depth-first search of the graph starting at node 'v'. The function returns nothing.
// a. Mark the node 'v' as visited by setting visited[v] to true
// b. For each neighbor 'w' of node 'v' (i.e. for each column in row v of adjMatrix):
// i. If the edge from node 'v' to node 'w' exists (i.e. adjMatrix[v][w] is 1) and 'w' has not been visited yet (i.e. visited[w] is false), call the 'DFS' function recursively with 'w' as input
// Call the 'DFS' function with node 0 as input
// Check if all nodes have been visited (i.e. if visited[i] is true for all i from 0 to n-1)
// If all nodes have been visited, output "Graph is connected"
// If some nodes have not been visited, output "Graph is not connected"


// Time Complexity Analysis
// The program uses a DFS traversal to check if all vertices can be reached from the first vertex (vertex 0). If any vertex is not reachable, then the graph is not connected. The time complexity of this algorithm is O(n^2), where n is the number of vertices in the graph, because we visit each vertex once and check its adjacency with each of the other vertices.


// Sample Input
// 4 3
// 0 1
// 1 2
// 2 0
