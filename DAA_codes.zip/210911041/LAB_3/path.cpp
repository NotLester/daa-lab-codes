#include <iostream>
#include <vector>

using namespace std;

bool findPath(vector<vector<int>>& graph, int start, int end, vector<bool>& vis, vector<int>& path) {
    vis[start] = true;
    path.push_back(start);

    if (start == end) return true;

    for (int i=0; i<graph.size(); i++) {
        if (graph[start][i] && !vis[i]) {
            if (findPath(graph,i,end,vis,path)) return true;
        }
    }

    path.pop_back();
    return false;
}

int main() {

//#ifndef ONLINE_JUDGE
    //freopen("input.txt","r",stdin);
    //freopen("output.txt","w",stdout);
//#endif

    int n, m, start, end;
    cout<< "Enter node, edge, starting node and ending node respectively: ";
    cin >> n >> m >> start >> end;

    vector<vector<int>> graph(n, vector<int>(n, 0));
    for (int i = 0; i < m; i++) {
        int u, v;
        cin >> u >> v;
        graph[u][v] = 1;
    }

    vector<bool> visited(n, false);
    vector<int> path;
    bool found_path = findPath(graph, start, end, visited, path);

    if (found_path) {
        cout << "Path found: ";
        for (int vertex : path) {
            cout << vertex << " ";
        }
    } else {
        cout << "Path not found";
    }

    return 0;
}

/*
4 4 2 3
0 1
1 2
2 3
3 0
*/






























// PseudoCode
// Define a function DFS(graph, start, end, visited, path)
// Set visited[start] = true and add start to the path
// If start == end, return true
// For every neighbor of start in the graph:
// a. If there is an edge between start and neighbor and neighbor is not visited:
// i. Recursively call DFS(graph, neighbor, end, visited, path)
// ii. If the function returns true, return true
// If no path is found, remove the last node from the path and return false


// Time Complexity Analysis
// The above code implements the Depth First Search (DFS) algorithm to find a path between two nodes in a graph. The algorithm starts from the start node and explores each possible path in a depth-first manner until it reaches the end node. During the search, the algorithm keeps track of visited nodes to avoid infinite loops.

// The implementation uses an adjacency matrix to represent the graph, where graph[i][j] is 1 if there is an edge between nodes i and j, and 0 otherwise. The algorithm takes the graph, start node, end node, a vector to keep track of visited nodes, and a vector to keep track of the path found so far as input parameters.

// The time complexity of the DFS algorithm is O(V+E), where V is the number of nodes in the graph, and E is the number of edges. In the implementation, we use an adjacency matrix to represent the graph, which takes O(V^2) space. The time complexity of reading input and constructing the adjacency matrix is O(m), where m is the number of edges.

// Therefore, the overall time complexity of the algorithm is O(V^2 + m), which is dominated by the construction of the adjacency matrix if the graph is dense. However, if the graph is sparse, the number of edges m is much smaller than V^2, and the time complexity is O(V+E).


// Sample input
// 4 4 2 3
// 0 1
// 1 2
// 2 3
// 3 0
