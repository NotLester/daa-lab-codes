#include<iostream>
using namespace std;

void bubbleSort(int arr[], int pos[], int n)  {
    for (int i = 0; i < n-1; i++)
        for (int j = 0; j < n-i-1; j++)
            if (arr[j] > arr[j+1]){
                swap(arr[j], arr[j+1]);
                swap(pos[j], pos[j+1]);
            }
}

int main() {
    int n, c;
    cout << "Enter number of containers: ";
    cin >> n;
    cout << "Enter total Capacity: ";
    cin >> c;

    int W[n];
    int X[n] = {0};
    int pos[n];

    cout << "Enter the weights:";
    for(int i = 0; i < n; i++) {
        cin >> W[i];
        pos[i] = i;
    }

    bubbleSort(W, pos, n);

    for(int i = 0; i < n && W[i] <= c; i++){
        X[pos[i]] = 1;
        c -= W[i];
    }

    cout << "Selected Items: ";
    for(int i = 0; i < n; i++){
        cout << X[i] << " ";
    }
}
