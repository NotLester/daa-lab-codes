#include <bits/stdc++.h>
using namespace std;

class Graph{
    int V;
    list<int>* adj;
public:
    Graph(int V) {
        this -> V = V;
        adj = new list<int>[V];
    }

    void addEdge(int u, int v) {
        adj[u].push_back(v);
    }

    void TopSortUtil(int v, bool vis[], stack<int>& Stack) {
        vis[v] = 1;
        for (auto i = adj[v].begin(); i != adj[v].end(); i++) {
            if (!vis[*i]) TopSortUtil(*i,vis,Stack);
        }
        Stack.push(v);
    }

    void TopSort() {
        stack<int> Stack;
        bool* vis = new bool[V];
        for (int i=0; i<V; i++) vis[i] = 0;

        for (int i=0; i<V; i++) {
            if (!vis[i])
                TopSortUtil(i,vis,Stack);
        }
        while (!Stack.empty()) {
            cout<< Stack.top() << " ";
            Stack.pop();
        }
        delete [] vis;
    }
};

int main() {

    int v,e;
    cout<< "Enter number of vertices: ";
    cin>> v;
    cout<< "Enter number of edges: ";
    cin>> e;

    Graph g(v);

    cout<< "Enter source and destination: " <<endl;
    for (int i=0; i<e; i++) {
        int u,v;
        cin>> u >> v;
        g.addEdge(u,v);
    }

    cout<< "Topological sort order: ";
    g.TopSort();

    return 0;
}
