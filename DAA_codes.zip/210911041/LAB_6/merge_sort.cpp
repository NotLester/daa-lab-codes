#include <iostream>
using namespace std;

void merge_array(int a[], int s, int mid, int e) {
    int left_size = mid-s+1;
    int right_size = e-mid;
    int left[left_size], right[right_size];
    for (int i=0; i<left_size; i++) left[i] = a[s+i];
    for (int i=0; i<right_size; i++) right[i] = a[mid+1+i];

    int i = 0, j = 0, k = s;
    while (i < left_size && j<right_size) {
        if (left[i] <= right[j]) a[k++] = left[i++];
        else a[k++] = right[j++];
    }

    while (i<left_size) a[k++] = left[i++];
    while (j<right_size) a[k++] = right[j++];

}

void merge_sort(int a[], int s, int e) {
    if (s >= e) return;
    int mid = (s+e)/2;
    merge_sort(a,s,mid);
    merge_sort(a,mid+1,e);
    merge_array(a,s,mid,e);
}

int main() {

    int n;
    cout<< "Enter the size of array: ";
    cin>> n;
    int a[n];
    cout<< "Enter elements: ";
    for (int i=0; i<n; i++) cin>> a[i];

    merge_sort(a,0,n-1);
    cout<< "Sorted array (using Merge-sort): ";
    for (int i=0; i<n; i++) cout<< a[i] << " ";

    return 0;
}
