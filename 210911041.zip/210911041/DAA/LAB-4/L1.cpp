#include <iostream>
using namespace std;

void max_container(int wt[], int n,int c) {
    int count = 0;
    int cap=0,pos;
    for(int j=0;j<n;j++) {
        int min=100;
        for(int i=0;i<n;i++) {
            if(wt[i]<min && wt[i]!=-1) {
                min=wt[i];
                pos=i;
            }
        }
        cap+=wt[pos];
        if(cap<=c) {
            count++;
            wt[pos]=-1;
        }
        else{
            break;
        }
    }
    cout<<"Maximum no. of containers loaded is "<<count;
}
int main()
{
    int n;
    cin>> n;
    int wt[n];
    for (int i=0; i<n; i++) cin>> wt[i];
    int c;
    cin>> c;
    max_container(wt,n,c);
    return 0;
}


// 6
// 20 10 30 5 15 25
// 40