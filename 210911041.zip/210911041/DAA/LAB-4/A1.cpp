#include <iostream>
#include <algorithm>
using namespace std;

bool compare(int a, int b) {
    return a > b;
}

int main() {
    int n, c; 
    cin >> n >> c;

    int items[n];
    for (int i = 0; i < n; i++) {
        cin >> items[i];
    }

    sort(items, items + n, compare); 

    int containers = 0; 
    int weight = 0; 
    for (int i = 0; i < n; i++) {
        if (weight + items[i] > c) {
            containers++; 
            weight = 0;
        }
        weight += items[i]; 
    }
    containers++; 

    cout << containers << endl; 

    return 0;
}

// 6 10
// 2 3 5 4 7 1

