#include <iostream>
using namespace std;

int c;

void insertionSort(int a[],int n) {
    int j;
    c++;
    for(int i=1; i<n; i++) {
        c++;
        int temp =a[i];
        c++;
        for (j=i-1; j>=0 && a[j]>temp; j--) {
            c++;
            a[j+1]=a[j];
            c++;
        }
        c++;
        a[j+1]=temp;
    }
}


int main() {

    // freopen("input.txt","r",stdin);
    // freopen("output.txt","w",stdout);

    int n;
    cout<< "Enter no. of elements: ";
    cin>>n;
    int a[n];
    for(int i=0; i<n; i++)
        cin>>a[i];

    insertionSort(a,n);

    cout<<"Step Count:  "<<c<<endl;
    for(int i=0; i<n; i++)
        cout<<a[i]<<" ";


    return 0;
}
