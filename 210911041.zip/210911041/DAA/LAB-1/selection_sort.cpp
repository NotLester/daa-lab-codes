#include <iostream>
using namespace std;

int c;

void selectionSort(int a[],int n) {
    int sm,s;
    c++;
    for(int i=0;i<n-1;i++) {
        c++;
        s=i;
        c++;
        sm=a[i];
        c++;
        for(int j=i+1;j<n;j++) {
            c++;
            c++;
            if(sm>a[j]) {
                c++;
                sm=a[j];
                c++;
                s=j;
            }
        }
        c++;
        a[s]=a[i];
        c++;
        a[i]=sm;
    }
}

int main() {

    // freopen("input.txt","r",stdin);
    // freopen("output.txt","w",stdout);

    int n;
    cout<< "Enter no. of elements: ";
    cin>>n;
    int a[n];
    for(int i=0;i<n;i++)
        cin>>a[i];
    selectionSort(a,n);
    cout<<"Step Count:  "<<c<<endl;
    for(int i=0;i<n;i++)
        cout<<a[i]<<" ";


    return 0;
}
