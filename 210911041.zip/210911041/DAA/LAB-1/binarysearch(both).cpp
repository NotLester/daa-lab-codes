#include <iostream>
using namespace std;
int c;

int binarySearch(int a[], int n, int x) {
    int lo=0, hi=n-1;
    c++;
    while (lo <= hi) {
        c++;
        int mid = (hi+lo)/2;
        c++;
        if (a[mid] == x) {
            c++;
            return mid;
        }
        else if (a[mid] > x) {
            c++;
            hi = mid - 1;
            c++;
        }
        else {
            c++;
            lo = mid +1;
            c++;
        }
    }
    return -1;
}

int recbinSearch(int a[], int x, int lo, int hi) {
    if (lo > hi) {
        c++;
        return -1;
    }
    int mid = (hi+lo)/2;
    c++;
    if (a[mid] == x) {
        c++;
        return mid;
    }
    else if (a[mid] > x) {
        c++;
        return recbinSearch(a,x,lo,mid-1);
    }
    else {
        return recbinSearch(a,x,mid+1,hi);
    }
}

int main() {
    int n;
    cout<< "Enter no. of elements: ";
    cin>> n;
    int a[n];
    for (int i=0; i<n; i++) cin>> a[i];
    int x;
    cin>> x;
    int f1 = binarySearch(a,n,x);
    cout<< "Step Count: "<< c <<endl;
    if (f1 != -1) cout<< "FOund" <<endl;
    else cout<< "Not Found"<<endl;
    c= 0;
    int f2 = recbinSearch(a,x,0,n-1);
    cout<< "Step Count(rec): "<< c <<endl;
    if (f2 != -1) cout<< "FOund" <<endl;
    else cout<< "Not Found"<<endl;
  return 0;
}
