#include <iostream>
using namespace std;


int c;

void bubblesort(int a[],int n) {
    for(int i=0;i<n-1;i++) {
        c++;
        for(int j=0;j<n-i-1;j++) {
            c++;
            c++;
            if(a[j]>a[j+1]) {
                int temp=a[j];
                c++;
                a[j]=a[j+1];
                c++;
                a[j+1]=temp;
                c++;
            }
        }
    }
    c++;
}


int main() {

	// freopen("input.txt","r",stdin);
	// freopen("output.txt","w",stdout);

	int n;
    cout<< "Enter no. of elements: ";
    cin>>n;
    int a[n];
    for(int i=0;i<n;i++)
        cin>>a[i];
    bubblesort(a,n);
    cout<<"Step Count:  "<<c <<endl;
    for(int i=0;i<n;i++)
        cout<<" "<<a[i];
	return 0;
}
