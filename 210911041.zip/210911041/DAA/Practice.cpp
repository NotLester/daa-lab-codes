#include <iostream>
#include <queue>
using namespace std;

int V,E;

void dfs(int a[][10], int src, int vis[]) {
    // cout<< src <<" ";
    vis[src] = 1;
    for (int i=1; i<=V; i++) {
        if (a[src][i] == 1 && (!vis[i])) {
            dfs(a,i,vis);
        }
    }
}
void bfs(int a[][10], int src, int vis[]) {
    queue<int> q;
    q.push(src);
    vis[src] = 1;
    int node;
    while (!q.empty()) {
        node = q.front(); q.pop();
        cout<< node << " ";
        for (int i=1; i<=V; i++) {
            if (a[node][i] == 1 && (!vis[i])) {
                q.push(i);
                vis[i] = 1;
            }
        }
    }
}

int findMother(int a[][10]) {
    int vis[V+1] = {0};
    int last_node = 1;
    for (int i=1; i<=V; i++) {
        if (!vis[i]) {
            dfs(a,i,vis);
            last_node = i;
        }
    }
    for (int i=1; i<=V; i++) vis[i] = 0;
    dfs(a,last_node,vis);
    for (int i=1; i<=V; i++) {
        if (!vis[i]) return -1;
    }
    return last_node;
}
bool isConnected(int a[][10]) {
    int vis[V+1] = {0};
    dfs(a,1,vis);
    for (int i=1; i<=V; i++) {
        if (!vis[i]) return false;
    }
    return true;
}
bool hasCycle(int a[][10], int vis[], int parent[], int u){
    vis[u] = 1;
    for (int i=1; i<=V; i++) {
        if (a[u][i]) {
            if (!vis[i]) {
                parent[i] = u;
                if (hasCycle(a,vis,parent,i)) {
                    return true;
                }
            }
            else if (parent[u]!= i) return true;
        }
    }
    return false;
}
bool find_Path(int a[][10], int s, int e, int vis[],vector<int>path){
    vis[s] = 1;
    path.push_back(s);
    for (int i=1; i<=V; i++) {
        if (a[s][i] == 1 && (!vis[i])) {
            if (find_Path(a,i,end,vis,path)) {
                return true;
            }
        }
    }
    path.pop_back();
    return false;
}
int main() {

    cin>> V >> E;
    int a[10][10];
    for (int i=1; i<V+1; i++) {
        for (int j=1; j<V+1; j++) {
            a[i][j] = 0;
        }
    }
    for (int i=0; i<E; i++) {
        int p,q;
        cin>> p >> q;
        a[p][q] = 1;
    }
    int vis[V+1] = {0};
    dfs(a,1,vis);
    cout<< endl;
    for (int i=0; i<=V; i++) vis[i] = 0;
    bfs(a,1,vis);
    cout<< endl;
    cout<< findMother(a) <<endl;
    cout<< isConnected(a) <<endl;
    for (int i=0; i<=V; i++) vis[i] = 0;
    int parent[V+1] = {-1};
    bool cyc = false;
    for (int i=1; i<=V; i++) {
        if (!vis[i]) {
            if (hasCycle(a,vis,parent,i)) {
                cyc = 1;
                break;
            }
        }
    } 
    cout<< cyc << endl;
    for (int i=0; i<=V; i++) vis[i] = 0;
    vector<int> path;
    cout<< find_Path(a,1,5,vis,path);
    return 0;
}