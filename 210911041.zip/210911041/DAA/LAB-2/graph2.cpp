#include <iostream>
#include <vector>

using namespace std;

// Define a function to perform DFS on the graph
bool DFS(vector<vector<int>>& graph, int start, int end, vector<bool>& visited, vector<int>& path) {
    visited[start] = true;
    path.push_back(start);

    if (start == end) {
        return true;
    }

    for (int neighbor = 0; neighbor < graph.size(); neighbor++) {
        if (graph[start][neighbor] && !visited[neighbor]) {
            if (DFS(graph, neighbor, end, visited, path)) {
                return true;
            }
        }
    }

    path.pop_back();
    return false;
}


bool findPath(vector<vector<int>>& graph, int start, int end, vector<bool>& vis, vector<int> path) {
	vis[start] = true;
	path.push_back(start);
	
	if (start == end) return true;;
	
	for (int neighbor=0; neighbor<graph.size(); neighbor++) {
		if (graph[start][neighbor] && !vis[neighbor]) {
			if (findPath(graph,neighbor,end,vis,path)) return true;
		}
	}
	
	path.pop_back();
	return false;
}

int main() {
	
#ifndef ONLINE_JUDGE
	freopen("input.txt","r",stdin);
	freopen("output.txt","w",stdout);
#endif
		
	int n, m, start, end;
    cin >> n >> m >> start >> end;

    vector<vector<int>> graph(n, vector<int>(n, 0));
    for (int i = 0; i < m; i++) {
        int u, v;
        cin >> u >> v;
        graph[u][v] = graph[v][u] = 1;
    }

    vector<bool> visited(n, false);
    vector<int> path;
    bool found_path = findPath(graph, start, end, visited, path);

    if (found_path) {
        cout << "Path found: ";
        for (int vertex : path) {
            cout << vertex << " ";
        }
    } else {
        cout << "Path not found";
    }
	
	return 0;
}
