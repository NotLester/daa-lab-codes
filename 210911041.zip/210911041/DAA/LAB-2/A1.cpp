#include <iostream>
#include <queue>
using namespace std;

int V,E;

void even_node_bfs(int graph[][10], bool vis[], int src) {
    queue<int> q;
    q.push(src);
    vis[src] = 1;

    while (!q.empty()) {
        int node = q.front(); q.pop();
        if (node % 2 == 0) cout<< node << " ";
        for (int i=1; i<=V; i++) {
            if (graph[src][i] && (!vis[i])){
                q.push(i);
                vis[i] = 1;
            }
        }
    }
}

int main() {

    cin>> V >> E;
    int graph[10][10];
    for (int i=1;i<=V; i++) {
        for (int j=1; j<=V; j++) {
            graph[i][j] = 0;
        }
    }
    for (int i=0; i<E; i++) {
        int p,q;
        cin>> p >> q;
        graph[p][q] = 1;
    }
    int src;
    cin>> src;
    bool vis[V+1] = {0};
    even_node_bfs(graph,vis,src);

    return 0;
}

// 5 6
// 1 2
// 2 3
// 3 4
// 4 5
// 1 4
// 2 4
// 1