#include <iostream>
using namespace std;

int V,E;

void odd_node_dfs(int graph[][10], bool vis[], int src) {
    vis[src] = 1;
    if (src % 2 != 0) {
        cout<< src << " ";
    }
    for (int i=1; i<=V; i++) {
        if (graph[src][i] && (!vis[i])) {
            odd_node_dfs(graph,vis,i);
        }
    }
}

int main() {

    cin>> V >> E;
    int graph[10][10];
    for (int i=1;i<=V; i++) {
        for (int j=1; j<=V; j++) {
            graph[i][j] = 0;
        }
    }
    for (int i=0; i<E; i++) {
        int p,q;
        cin>> p >> q;
        graph[p][q] = 1;
    }
    int src;
    cin>> src;
    bool vis[V+1] = {0};
    odd_node_dfs(graph,vis,src);
    return 0;
}

// 5 6
// 1 2
// 2 3
// 3 4
// 4 5
// 1 3
// 1 5
// 1