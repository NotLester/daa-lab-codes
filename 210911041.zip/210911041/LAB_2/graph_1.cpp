#include <iostream>
using namespace std;

int v, e;

class Queue {
    public:
        int a[100];
        int front, rear;
        Queue() {
            front = -1;
            rear = 0;
        }
        bool isEmpty() {
            if (front == rear)
            return true;
            else
            return false;
        }
        void enqueue(int x) {
            if (rear == 99) return;
            else if (rear == 0) {
                a[rear++] = x;
                front = 0;
            }
            else {
                a[rear++] = x;
            }
        }
        int dequeue() {
            if (isEmpty())
                cout << "Queue is Emtpy";
            else {
                return (a[front++]);
            }
        }
        void display() {
            int i;
            cout << "\nQueue : ";
            for (i = front; i <= rear; i++)
            cout << a[i] << "\t";
        }
};

void dfs(int a[11][11], int source, int visited[]) {
    cout << (source + 1) << " ";
    visited[source] = 1;
    for (int i = 1; i <=v; i++) {
        if (a[source][i] == 1 && (!visited[i])) {
            dfs(a, i, visited);
        }
    }
}

void bfs(int a[11][11], int source, int visited[]) {
    Queue q;
    q.enqueue(source);
    while (!q.isEmpty()) {
        int z = q.dequeue();
        cout << z << " ";
        for (int i = 0; i < v; i++) {
            if (a[z][i] == 1 && visited[i] == 0) {
                visited[i] = 1;
                q.enqueue(i);
            }
        }
        visited[z] = 1;
    }
}


void pseudoDFS(int a[11][11], int source, int visited[]) {
    visited[source] = 1;
    for (int i = 1; i <=v; i++) {
        if (a[source][i] == 1 && (!visited[i])) {
            dfs(a, i, visited);
        }
    }
}

int findMother(int a[][11], int source, int visited[]) {
    int prev = 0;
    for (int i=0; i<v; i++) {
        if (visited[i] == 0) {
            pseudoDFS(a,i,visited);
            prev = i;
        }
    }
    for (int i=0; i<10; i++) visited[i] = 0;
    pseudoDFS(a,prev,visited);
    for (int i=0; i<v; i++) {
        if (visited[i] == 0) return -1;
    }
    return v;
}

void create_Transpose(int a[11][11], int v) {
    for (int i=0; i<v; i++) {
        for (int j=0; j<v; j++) {
            a[i][j] = a[j][i];
        }
    }
}

int main() {
    int a[11][11], n, m, x, i, j;
    cout << "Enter No. of vertices : ";
    cin >> v;
    cout << "Enter No. of edges : ";
    cin >> e;

    for (int i = 0; i < v; i++)
    for (int j = 0; j < v; j++)
        a[i][j] = 0;

    for (i = 1; i <= e; i++) {
        int p, q;
        cin>> p >> q;
        a[p][q] = 1;
    }

    cout << "\nThe Adjacency Matrix is : \n\n";
    for (i = 0; i < v; i++) {
        for (j = 0; j < v; j++){
            cout << a[i][j] << " ";
        }
        cout << endl;
    }

    cout << endl;
    //cout << "Enter Source : ";
    int source;
    //cin >> source;
    int visited[11];
    for (i = 0; i < v; i++)
        visited[i] = 0;
    //dfs(a, source - 1, visited);
    //findMother(a,0,visited);
    create_Transpose(a,v);
    cout << "\nThe Adjacency Matrix is : \n\n";
    for (i = 0; i < v; i++) {
        for (j = 0; j < v; j++) {
            cout << a[i][j] << " ";
        }
        cout << endl;
    }
    cout<< endl;

    //bfs(a, source,visited);
}
