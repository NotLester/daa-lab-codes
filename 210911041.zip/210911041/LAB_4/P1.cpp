#include <bits/stdc++.h>
using namespace std;

int cnt;

int ContainerLoading(int capacity, int weights[], int n) {
    sort(weights,weights+n);
    int itemsStoredWeight = 0;
    int i=0;
    while (itemsStoredWeight <= capacity && capacity > -1 && i<n) {
        itemsStoredWeight += weights[i];
        capacity -= weights[i];
        cnt++;
        i++;
    }
    return itemsStoredWeight;
}

int main() {

    int capacity;
    cin>> capacity;
    int n;
    cin>> n;
    int weights[n];
    for (int i=0; i<n; i++) cin>> weights[i];

    int res = ContainerLoading(capacity, weights, n);
    cout<< "We are able to store " << cnt << " items with total weight: " << res <<endl;

    return 0;
}
