#include <iostream>
using namespace std;

int V, E;

class Queue
{
public:
    int a[100];
    int front, rear;
    Queue() {
        front = -1;
        rear = -1;
    }
    bool isEmpty() {
        return (front == -1);
    }
    bool isFull() {
        return (rear == 99);
    }
    void enqueue(int x)
    {
        if (isFull())
            return;
        else if (isEmpty()) {
            front = 0;
            rear = 0;
        }
        else {
            rear++;
        }
        a[rear] = x;
    }
    int dequeue() {
        if (isEmpty())
            return -1;
        int val = a[front];
        if (front == rear) {
            front = -1;
            rear = -1;
        }
        else {
            front++;
        }
        return val;
    }
    void display() {
        for (int i = front; i <= rear; i++)
            cout << a[i] << "\t";
    }
};



void printMatrix(int a[][10], int V) {
    for (int i = 0; i < V; i++) {
        for (int j = 0; j < V; j++) {
            cout << a[i][j] << " ";
        }
        cout << endl;
    }
    cout << endl;
}

void bfs(int a[10][10], int source, int visited[]) {
    Queue q;
    visited[source - 1] = 1;
    q.enqueue(source);
    while (!q.isEmpty()) {
        int z = q.dequeue();
        cout << z << "  ";
        for (int i = 0; i < V; i++) {
            if (a[z - 1][i] == 1 && visited[i] == 0) {
                visited[i] = 1;
                q.enqueue(i + 1);
            }
        }
        visited[z - 1] = 1;
    }
}

void dfs(int a[][10], int source, int visited[]) {
    cout << source + 1 << "  ";
    visited[source] = 1;
    for (int i = 1; i <= V; i++) {
        if (a[source][i - 1] == 1 && (!visited[i - 1])) {
            dfs(a, i - 1, visited);
        }
    }
}

void pseudoDFS(int a[][10], int source, int visited[]) {
    visited[source] = 1;
    for (int i = 1; i <= V; i++) {
        if (a[source][i - 1] == 1 && (!visited[i - 1])) {
            pseudoDFS(a, i - 1, visited);
        }
    }
}

int getMotherVertex(int a[][10]) {
    int visited[V] = {0};
    int last_node = 0;
    for (int i=0; i<V; i++) {
        if (!visited[i]) {
            pseudoDFS(a,i,visited);
            last_node = i;
        }
    }
    for (int i=0; i<V; i++) visited[i] = 0;
    pseudoDFS(a,last_node+1,visited);
    for (int i=0; i<V; i++) {
        if (!visited[i]) return -1;
    }
    return last_node+1;
}

void getTranspose(int a[][10], int V, int transMatrix[][10]) {
    for (int i=0; i<V; i++) {
        for (int j=0; j<V; j++) {
            transMatrix[i][j] = a[j][i];
        }
    }
}

int main() {

// #ifndef ONLINE_JUDGE
//     freopen("input.txt","r",stdin);
//     freopen("output.txt","w",stdout);
// #endif

    int a[10][10];
    cout << "Enter no. of V : ";
    cin >> V;
    cout << "Enter no. of E : ";
    cin >> E;
    for (int i = 0; i < V; i++) {
        for (int j = 0; j < V; j++)
            a[i][j] = 0;
    }


    for (int i = 1; i <= E; i++) {
        int p, q;
        cin >> p >> q;
        a[p - 1][q - 1] = 1;
    }
    int source;
    cin >> source;

    cout<< "\nOriginal Matrix: " <<endl;
    printMatrix(a,V);

    int visited[V] = {0};

    cout<< "DFS traversal: ";
    dfs(a, source - 1, visited);
    cout<< endl;
    for (int i=0;  i<V; i++) visited[i] = 0;
    cout<< "BFS traversal: ";
    bfs(a,source,visited);
    cout<<endl;

    cout<< "Mother Vertex: "<< getMotherVertex(a) <<endl;

    int transMatrix[V][10];
    getTranspose(a,V,transMatrix);
    cout<< "Transpose matrix: "<<endl;
    printMatrix(transMatrix,V);

    return 0;
}


//5
//6
//1 2
//2 3
//3 1
//3 4
//4 5
//5 3
//1
