#include <iostream>
#include <vector>

using namespace std;

bool hasCycle(vector<vector<int>>& graph, vector<bool>& visited, vector<int>& parent, int u) {
    visited[u] = true;
    for (int v = 0; v < graph.size(); v++) {
        if (graph[u][v]) {
            if (!visited[v]) {
                parent[v] = u;
                if (hasCycle(graph, visited, parent, v)) {
                    return true;
                }
            } else if (parent[u] != v) {
                return true;
            }
        }
    }
    return false;
}


int main() {

//#ifndef ONLINE_JUDGE
	//freopen("input.txt","r",stdin);
	//freopen("output.txt","w",stdout);
//#endif

	// Read input
    int n, m;
    cin >> n >> m;
    vector<vector<int>> graph(n, vector<int>(n, 0));
    for (int i = 0; i < m; i++) {
        int u, v;
        cin >> u >> v;
        graph[u][v] = graph[v][u] = 1;
    }

    vector<bool> visited(n, false);
    vector<int> parent(n, -1);

    bool has_cycle = false;
    for (int u = 0; u < n; u++) {
        if (!visited[u]) {
            if (hasCycle(graph, visited, parent, u)) {
                has_cycle = true;
                break;
            }
        }
    }

    if (has_cycle) {
        cout << "The graph has a cycle." << endl;
    } else {
        cout << "The graph does not have a cycle." << endl;
    }

	return 0;
}







//Pseudocode
    // Initialize a boolean array visited[] to keep track of visited vertices. Initialize all vertices as not visited.
    // Initialize a vector parent[] to keep track of the parent vertex of each vertex in the DFS tree. Initialize all parent vertices as -1.
    // For each vertex v in the graph:
    // a. If v is not visited, perform DFS on the vertex v and set its parent as -1.
    // During the DFS traversal:
    // a. Mark the current vertex as visited.
    // b. For each adjacent vertex u of the current vertex v:
    // i. If u is not visited, set its parent as v and recursively perform DFS on u.
    // ii. If u is visited and its parent is not v, then we have found a cycle.
    // If a cycle is found in step 4, return true.
    // If no cycle is found, return false.

//Time Complexixty
// The time complexity of this algorithm is O(n^2), where n is the number of vertices in the graph. This is because we need to visit each vertex and its adjacent vertices, which takes O(n^2) time in the worst case for an adjacency matrix representation. The space complexity is also O(n^2) to store the adjacency matrix.


// Sample input
// 4 4
// 0 1
// 1 2
// 2 3
// 3 0
