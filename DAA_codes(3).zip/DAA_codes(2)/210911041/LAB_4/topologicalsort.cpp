#include<bits/stdc++.h>
using namespace std;

void topological_sort(int graph[100][100], int indegree[100], int n) {
    queue<int> q;

    for (int i = 0; i < n; i++) {
        if (indegree[i] == 0) {
            q.push(i);
        }
    }

    while (!q.empty()) {
        int u = q.front();
        q.pop();
        cout << u << " ";

        for (int v = 0; v < n; v++) {
            if (graph[u][v] == 1) {
                indegree[v]--;
                if (indegree[v] == 0) q.push(v);
            }
        }
    }
}

int main() {
    
    int graph[100][100], indegree[100]= {0};
    memset(graph, 0, sizeof(graph));
    
    int n, e;
    cout << "Enter the number of vertices: ";
    cin >> n;

    cout << "Enter the number of edges: ";
    cin >> e;

    cout << "Enter the edges:\n";
    for (int i = 0; i < e; i++) {
        int u, v;
        cin >> u >> v;
        graph[u][v] = 1;
        indegree[v]++;
    }

    cout << "Topological sort: ";
    topological_sort(graph,indegree,n);

    return 0;
}
 