#include <bits/stdc++.h>
using namespace std;

int V,E;

int minDistance(int dist[], bool shrtpthSet[]) {
    int mini = INT_MAX, min_idx;
    for (int v=1; v<=V; v++) {
        if (shrtpthSet[v] == false && dist[v] <= mini) {
            mini = dist[v];
            min_idx = v;
        }
    }
    return min_idx;
}

void dijkstra(int graph[][10], int src) {
    int dist[V+1];
    bool shrtpthSet[V+1];
    for (int i=1; i<=V; i++) {
        dist[i] = INT_MAX;
        shrtpthSet[i] = 0;
    }
    dist[src] = 0;
    for (int i=1; i<=V-1; i++) {
        int u = minDistance(dist,shrtpthSet);
        shrtpthSet[u] = 1;
        for (int v=1; v<=V; v++) {
            if (!shrtpthSet[v] && graph[u][v] && dist[u] != INT_MAX && dist[u]+graph[u][v] < dist[v])
                dist[v] = dist[u] + graph[u][v];
        }
    }

    for (int i=1; i<=V; i++) cout<< i << "           " << dist[i] <<endl;

}

int main() {

    cout<< "Enter total number of vertices and edges: ";
    cin>> V >> E;
    int graph[10][10];
    for (int i=0; i<=V; i++) {
        for (int j=0; j<=V; j++) {
            graph[i][j] = 0;
        }
    }

    cout<< "Enter source, destination and cost respectively: "<<endl;
    for (int i=0; i<E; i++) {
        int p,q,cost;
        cin>> p >> q >> cost;
        graph[p][q] = cost;
    }

    dijkstra(graph,1);

    return 0;
}
/*
5 6
1 2 36
2 3 32
3 5 12
2 4 63
2 5 1
1 5 33
*/


