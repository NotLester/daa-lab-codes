#include <iostream>
using namespace std;

int cnt = 0;

int binarySearchIt(int a[], int n, int x) {

    int low = 0;  cnt++;
    int high = n-1; cnt++;

    while (low <= high) {
        cnt++;
        int mid = (low+high)/2;
        cnt++;

        cnt++;
        if (a[mid] == x) {
            cnt++;
            return mid;
        }

        else if (a[mid] > x) {
            cnt++;
            cnt++;
            high = mid - 1;
        }

        else {
            cnt++;
            low = mid + 1;
        }
    }
    cnt++;
    return -1;
}

int binSearchRec(int a[], int n, int x, int low, int high) {

    cnt++;
    if (low > high) {
        cnt++;
        return -1;
    }

    cnt++;
    int mid = (low + high) /2;

    cnt++;
    if (a[mid] == x) {
        cnt++;
        return mid;
    }

    else if (a[mid] > x) {
        cnt++;
        cnt++;
        return binSearchRec(a,n,x,low,mid-1);
    }

    else {
        cnt++;
        return binSearchRec(a,n,x,mid+1,high);
    }

}
int main() {

    int n,x ;
    cin>> n;
    int a[n];
    for (int i=0; i<n; i++) {
        cin>> a[i];
    }
    cin>> x;
    //cout<< "Found at index: "<< binarySearchIt(a,n,x) <<endl;
    cout<< "Found at index: "<< binSearchRec(a,n,x,0,n-1) <<endl;
    cout<< "Step Count: " << cnt << endl;


    return 0;
}


