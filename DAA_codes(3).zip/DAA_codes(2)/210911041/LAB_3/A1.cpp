#include <iostream>
#define MAX 100

using namespace std;

int graph[MAX][MAX];
int visited[MAX];
int n, e;

void dfs(int node, int component) {
    visited[node] = component;
    for (int i = 0; i < n; i++) {
        if (graph[node][i] == 1 && visited[i] == 0) {
            dfs(i, component);
        }
    }
}

int main() {
    int component = 0;
    cin >> n >> e;
    for (int i = 0; i < e; i++) {
        int u, v;
        cin >> u >> v;
        graph[u][v] = 1;
        graph[v][u] = 1;
    }
    for (int i = 0; i < n; i++) {
        if (visited[i] == 0) {
            component++;
            dfs(i, component);
        }
    }
    for (int i = 1; i <= component; i++) {
        cout << "Component " << i << ": ";
        for (int j = 0; j < n; j++) {
            if (visited[j] == i) {
                cout << j << " ";
            }
        }
        cout << endl;
    }
    return 0;
}

// 10 8
// 0 1
// 0 2
// 1 2
// 1 3
// 4 5
// 5 6
// 7 8
// 8 9
