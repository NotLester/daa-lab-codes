#include <iostream>
using namespace std;

int V=9,E;

int minDistance(int dist[], bool shrtpthSet[]) {
    int mini = INT_MAX, min_idx;
    for (int v=1; v<=V; v++) {
        if (shrtpthSet[v] == false && dist[v] <= mini) {
            mini = dist[v];
            min_idx = v;
        }
    }
    return min_idx;
}

void dijkstra(int graph[][10], int src) {
    int dist[V+1];
    bool shrtpthSet[V+1];
    for (int i=1; i<=V; i++) {
        dist[i] = INT_MAX;
        shrtpthSet[i] = 0;
    }
    dist[src] = 0;
    for (int i=1; i<=V-1; i++) {
        int u = minDistance(dist,shrtpthSet);
        shrtpthSet[u] = 1;
        for (int v=1; v<=V; v++) {
            if (!shrtpthSet[v] && graph[u][v] && dist[u] != INT_MAX && dist[u]+graph[u][v] < dist[v])
                dist[v] = dist[u] + graph[u][v];
        }
    }

    for (int i=1; i<=V; i++) {
        cout<< i << "           " << dist[i] <<endl;
    }

}

int main() {

    cin>> V >> E;
    int graph[10][10];
    for (int i=0; i<=V; i++) {
        for (int j=0; j<=V; j++) {
            graph[i][j] = 0;
        }
    }

    for (int i=0; i<E; i++) {
        int p,q,cost;
        cin>> p >> q >> cost;
        graph[p][q] = cost;
    }

    /*int graph[10][10] = { { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
                          { 0, 4, 0, 0, 0, 0, 0, 8, 0, 0},
                          { 4, 0, 8, 0, 0, 0, 0, 11, 0, 0 },
                          { 0, 8, 0, 7, 0, 4, 0, 0, 2, 0 },
                          { 0, 0, 7, 0, 9, 14, 0, 0, 0, 0 },
                          { 0, 0, 0, 9, 0, 10, 0, 0, 0, 0 },
                          { 0, 0, 4, 14, 10, 0, 2, 0, 0, 0 },
                          { 0, 0, 0, 0, 0, 2, 0, 1, 6, 0 },
                          { 8, 11, 0, 0, 0, 0, 1, 0, 7, 0 },
                          { 0, 0, 2, 0, 0, 0, 6, 7, 0, 0 }};*/



    dijkstra(graph,1);

    return 0;
}
/*
5 6
1 2 36s
2 3 32
3 5 12
2 4 63
2 5 1
1 5 33
*/


