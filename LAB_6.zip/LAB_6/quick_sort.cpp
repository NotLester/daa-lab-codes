#include <iostream>
using namespace std;

int Partition(int a[], int s, int e) {
    // Placing pivot
    int pivot = a[s];
    int cnt = 0;
    for (int i=s+1; i<=e; i++) {
        if (a[i] < pivot) cnt++;
    }
    int pivot_index = s + cnt;
    swap(a[pivot_index],a[s]);

    //Arranging elements based on pivot
    int i = s, j = e;
    while (i < pivot_index && j > pivot_index) {
        while (a[i] <= pivot_index) i++;
        while (a[j] > pivot_index) j--;
        if (a[i] > pivot && a[j] < pivot) swap(a[i++],a[j--]);
    }

    //return pivot index;
    return pivot_index;
}

void quick_sort(int a[], int s, int e) {
    if (s >= e) return;
    int p_index = Partition(a,s,e);
    quick_sort(a,s,p_index-1);
    quick_sort(a,p_index+1,e);
}

int main() {

    int n;
    cout<< "Enter the size of array: ";
    cin>> n;
    int a[n];
    cout<< "Enter elements: ";
    for (int i=0; i<n; i++) cin>> a[i];

    quick_sort(a,0,n-1);
    cout<< "Sorted array (using quick_sort): ";
    for (int i=0; i<n; i++) cout<< a[i] << " ";
    return 0;
}
