#include <bits/stdc++.h>
using namespace std;

int mini,maxi;

pair<int,int> MinMax(int a[], int n, int low, int high) {

    if (low == high) {
        return {a[low],a[low]};
    }
    if (high == low + 1) {
        if (a[low] < a[high]) {
            return {a[low],a[high]};
        }
        return {a[high],a[low]};
    }

    int mid = (low + high)/2;

    pair<int,int> left = MinMax(a,n,low,mid);
    pair<int, int> right = MinMax(a,n,mid+1,high);
    int LMin = left.first, LMax = left.second;
    int RMin = right.first, RMax = right.second;

    maxi = max(LMax, RMax);
    mini = min(LMin, RMin);

    return {mini,maxi};

}

int main() {

    int n;
    cout<< "Enter size of array: ";
    cin>> n;
    int a[n];
    cout << "Enter elements: ";
    for (int i=0; i<n; i++) cin>> a[i];

    pair<int,int> Ele = MinMax(a,n,0,n-1);
    cout<< "Maximum element: " << Ele.second << endl;
    cout<< "Minimum element: " << Ele.first <<endl;


    return 0;
}
